import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmpRoutingModule } from './emp-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    EmpRoutingModule
  ]
})
export class EmpModule { }
